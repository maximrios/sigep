# Changelog

## 2.1.0
- Add option to set a custom title to the <a> tag

## 2.0.0
- Code optimisations
- Destroy method
- Scroll distance from bottom
- Easing implimentation (1.3)
- Grunt intergration
- Travis CI intergration
- Update jQuery to 1.10.2

## 1.1.1
- Fix Firefox bug on tab theme in tab.css

## 1.1
- Add option for using images (with example)
- Code optimisations
- Update jQuery to 1.9.1

## 1.0
- Release